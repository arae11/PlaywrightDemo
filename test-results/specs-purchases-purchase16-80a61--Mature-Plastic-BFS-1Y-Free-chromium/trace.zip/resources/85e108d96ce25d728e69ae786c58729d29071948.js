/*!
    TAG V6.07.7433, smct.tag-railcard.co.uk
    Copyright 2012-2025 intent.ly Global Ltd
*/if(typeof window.$smctResources !== 'undefined') {
    console.warn('Cannot load Tag Resources more than once...');
} else {
    window.$smctResources = function() {
        var urls = {
            tag_url : 'https://js.smct.io/t/tag-v6.07.js',
            overlays_url : 'https://js.smct.io/o/overlays-v6.07.js',
            overlays_data_url : 'https://smct.co/ov5/load/',
            smc_debug_url :  '',
            client_debug_url : 'https://js.smct.io/dp/clientDebug-v2.00.js',
            basket_backup_script : '',
            basket_backup_endpoint : '',
            selector_tool_script : '',
            selector_tool_endpoint : '',
            smarter_codes_script: '',
            smarter_codes_endpoint: '',
            smc_jq : 'https://js.smct.io/jq/smcJQ-v3.4.1.js',
            ls_endpoint : 'https://ls.smct.io/lse1.3.html',
            notification_app : '',
            notification_checker : '',
            px2a_source_url: 'https://js.smct.io/e/events-1.6.0.min.js',
            px2b_endpoint_url: 'https://events.smct.co/',
            
            host : 'https://smct.co/',
            pxt_domain : 'https://ep.smct.co/',
            tag_data_url : 'https://smct.co/tm/data/',
            overlays_engage_url : 'https://ep.smct.co/ov4/e/',
            insights_url : 'https://ep.smct.co/insights/',
            url_track : 'https://ep.smct.co/ut/',
            client_debug_data : 'https://smct.co/cldbData/',
        }
            var sri = {
                tag_url : '',
                overlays_url : '',
                smc_debug_url :  '',
                client_debug_url : '',
                basket_backup_script : '',
                selector_tool_script : '',
                smarter_codes_script: '',
                smc_jq : '',
                notification_app : '',
                px2a_source_url: '',
                px2a_fingerprint_url: '',
            };
        
        var getURL = function(key, additional) {
            return urls[key];
        };

        var getSRI = function(key, additional) {
            return sri[key];
        };

        var getTagLoadedTime = function() {
            var microtime = 1749242109.7896;
            return Math.round(microtime*1000);
        };

        /* Deprecated */
        var runCode = function(key, isDebug) {
            return false;
        };
        
        return {
            getURL : getURL,
            getSRI : getSRI,
            getTagLoadedTime : getTagLoadedTime,
            runCode : runCode,
            tryer: function() {
                return false;
            },
            staticFiles : 0
        };}();
    }if(typeof window.$smctData !== 'undefined') {
    console.warn('Cannot load Tag Data more than once...');
} else {
	window.$smctData = {
			a:1,
			b:1,
			h:'https://smct.co/',
		o:'eyJ2ZXJzaW9uIjoiNi4wNyIsImlkIjoyODYyLCJuYW1lIjoicmFpbGNhcmQuY28udWsiLCJjc3NfYW5pbXMiOiIuc21jdC1hbmltYXRlZHstd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjoxczthbmltYXRpb24tZHVyYXRpb246MXM7LXdlYmtpdC1hbmltYXRpb24tZmlsbC1tb2RlOmJvdGg7YW5pbWF0aW9uLWZpbGwtbW9kZTpib3RofS5zbWN0LWFuaW1hdGVkLnNtY3QtaW5maW5pdGV7LXdlYmtpdC1hbmltYXRpb24taXRlcmF0aW9uLWNvdW50OmluZmluaXRlO2FuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6aW5maW5pdGV9LnNtY3QtYW5pbWF0ZWQuc21jdC1oaW5nZXstd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjoyczthbmltYXRpb24tZHVyYXRpb246MnN9LnNtY3QtYW5pbWF0ZWQuc21jdC1ib3VuY2VJbiwuc21jdC1hbmltYXRlZC5zbWN0LWJvdW5jZU91dCwuc21jdC1hbmltYXRlZC5zbWN0LWZsaXBPdXRYLC5zbWN0LWFuaW1hdGVkLnNtY3QtZmxpcE91dFl7LXdlYmtpdC1hbmltYXRpb24tZHVyYXRpb246Ljc1czthbmltYXRpb24tZHVyYXRpb246Ljc1c31ALXdlYmtpdC1rZXlmcmFtZXMgc21jdC1ydWJiZXJCYW5kezAley13ZWJraXQtdHJhbnNmb3JtOnNjYWxlWCgxKTt0cmFuc2Zvcm06c2NhbGVYKDEpfTMwJXstd2Via2l0LXRyYW5zZm9ybTpzY2FsZTNkKDEuMjUsLjc1LDEpO3RyYW5zZm9ybTpzY2FsZTNkKDEuMjUsLjc1LDEpfTQwJXstd2Via2l0LXRyYW5zZm9ybTpzY2FsZTNkKC43NSwxLjI1LDEpO3RyYW5zZm9ybTpzY2FsZTNkKC43NSwxLjI1LDEpfTUwJXstd2Via2l0LXRyYW5zZm9ybTpzY2FsZTNkKDEuMTUsLjg1LDEpO3RyYW5zZm9ybTpzY2FsZTNkKDEuMTUsLjg1LDEpfTY1JXstd2Via2l0LXRyYW5zZm9ybTpzY2FsZTNkKC45NSwxLjA1LDEpO3RyYW5zZm9ybTpzY2FsZTNkKC45NSwxLjA1LDEpfTc1JXstd2Via2l0LXRyYW5zZm9ybTpzY2FsZTNkKDEuMDUsLjk1LDEpO3RyYW5zZm9ybTpzY2FsZTNkKDEuMDUsLjk1LDEpfXRvey13ZWJraXQtdHJhbnNmb3JtOnNjYWxlWCgxKTt0cmFuc2Zvcm06c2NhbGVYKDEpfX1Aa2V5ZnJhbWVzIHNtY3QtcnViYmVyQmFuZHswJXstd2Via2l0LXRyYW5zZm9ybTpzY2FsZVgoMSk7dHJhbnNmb3JtOnNjYWxlWCgxKX0zMCV7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUzZCgxLjI1LC43NSwxKTt0cmFuc2Zvcm06c2NhbGUzZCgxLjI1LC43NSwxKX00MCV7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUzZCguNzUsMS4yNSwxKTt0cmFuc2Zvcm06c2NhbGUzZCguNzUsMS4yNSwxKX01MCV7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUzZCgxLjE1LC44NSwxKTt0cmFuc2Zvcm06c2NhbGUzZCgxLjE1LC44NSwxKX02NSV7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUzZCguOTUsMS4wNSwxKTt0cmFuc2Zvcm06c2NhbGUzZCguOTUsMS4wNSwxKX03NSV7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUzZCgxLjA1LC45NSwxKTt0cmFuc2Zvcm06c2NhbGUzZCgxLjA1LC45NSwxKX10b3std2Via2l0LXRyYW5zZm9ybTpzY2FsZVgoMSk7dHJhbnNmb3JtOnNjYWxlWCgxKX19LnNtY3QtcnViYmVyQmFuZHstd2Via2l0LWFuaW1hdGlvbi1uYW1lOnNtY3QtcnViYmVyQmFuZDthbmltYXRpb24tbmFtZTpzbWN0LXJ1YmJlckJhbmR9QC13ZWJraXQta2V5ZnJhbWVzIHNtY3Qtc2hha2V7MCUsdG97LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWigwKTt0cmFuc2Zvcm06dHJhbnNsYXRlWigwKX0xMCUsMzAlLDUwJSw3MCUsOTAley13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZTNkKC0xMHB4LDAsMCk7dHJhbnNmb3JtOnRyYW5zbGF0ZTNkKC0xMHB4LDAsMCl9MjAlLDQwJSw2MCUsODAley13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZTNkKDEwcHgsMCwwKTt0cmFuc2Zvcm06dHJhbnNsYXRlM2QoMTBweCwwLDApfX1Aa2V5ZnJhbWVzIHNtY3Qtc2hha2V7MCUsdG97LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWigwKTt0cmFuc2Zvcm06dHJhbnNsYXRlWigwKX0xMCUsMzAlLDUwJSw3MCUsOTAley13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZTNkKC0xMHB4LDAsMCk7dHJhbnNmb3JtOnRyYW5zbGF0ZTNkKC0xMHB4LDAsMCl9MjAlLDQwJSw2MCUsODAley13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZTNkKDEwcHgsMCwwKTt0cmFuc2Zvcm06dHJhbnNsYXRlM2QoMTBweCwwLDApfX0uc21jdC1zaGFrZXstd2Via2l0LWFuaW1hdGlvbi1uYW1lOnNtY3Qtc2hha2U7YW5pbWF0aW9uLW5hbWU6c21jdC1zaGFrZX1ALXdlYmtpdC1rZXlmcmFtZXMgc21jdC1wdWxzZXswJXstd2Via2l0LXRyYW5zZm9ybTpzY2FsZVgoMSk7dHJhbnNmb3JtOnNjYWxlWCgxKX01MCV7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUzZCgxLjA1LDEuMDUsMS4wNSk7dHJhbnNmb3JtOnNjYWxlM2QoMS4wNSwxLjA1LDEuMDUpfXRvey13ZWJraXQtdHJhbnNmb3JtOnNjYWxlWCgxKTt0cmFuc2Zvcm06c2NhbGVYKDEpfX1Aa2V5ZnJhbWVzIHNtY3QtcHVsc2V7MCV7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGVYKDEpO3RyYW5zZm9ybTpzY2FsZVgoMSl9NTAley13ZWJraXQtdHJhbnNmb3JtOnNjYWxlM2QoMS4wNSwxLjA1LDEuMDUpO3RyYW5zZm9ybTpzY2FsZTNkKDEuMDUsMS4wNSwxLjA1KX10b3std2Via2l0LXRyYW5zZm9ybTpzY2FsZVgoMSk7dHJhbnNmb3JtOnNjYWxlWCgxKX19LnNtY3QtcHVsc2V7LXdlYmtpdC1hbmltYXRpb24tbmFtZTpzbWN0LXB1bHNlO2FuaW1hdGlvbi1uYW1lOnNtY3QtcHVsc2V9QC13ZWJraXQta2V5ZnJhbWVzIHNtY3QtZmxhc2h7MCUsNTAlLHRve29wYWNpdHk6MX0yNSUsNzUle29wYWNpdHk6MH19QGtleWZyYW1lcyBzbWN0LWZsYXNoezAlLDUwJSx0b3tvcGFjaXR5OjF9MjUlLDc1JXtvcGFjaXR5OjB9fS5zbWN0LWZsYXNoey13ZWJraXQtYW5pbWF0aW9uLW5hbWU6c21jdC1mbGFzaDthbmltYXRpb24tbmFtZTpzbWN0LWZsYXNofSIsImNvbmZpZyI6eyJ0YWdSZWZyZXNoSUQiOjM1NjczLCJqUXVlcnlGb3JjZUxvYWQiOjAsImlnbm9yZUhhc2giOjEsImNhc2VTZW5zaXRpdmUiOjAsImluc2lnaHRzIjowLCJibG9ja0lmcmFtZSI6MCwicHhUcmFja09mZiI6MCwicnVsZXNVVEMiOjAsImZvcmNlT25EZWJ1ZyI6MCwicHhBcGMiOjEsIk92UmVxSW50IjowLCJGaXJzdENoYXJBc2NpaUZpeCI6MCwiZW5jb2RlQ29va2llcyI6MCwicmVmRXhhY3RNYXRjaCI6MCwibWlncmF0ZUNvb2tpZXNUb0xvY2FsU3RvcmFnZSI6MSwiZW5mb3JjZVNyaSI6MCwidGltZW91dCI6MzAwLCJzY2FubmVyVGltZSI6MzAwLCJjb29raWVNYXhBZ2VEYXlzIjoiIiwib3ZDb29raWVIaXN0b3J5IjoiIiwic3JjX2NvX2lvIjoiYXV0byIsImluc2lnaHRzX2F1dG8iOiIiLCJsczNyZHB0eVVJRCI6MSwiZHluYW1pY0VsZW1lbnRzIjp7IkNvbmZpcm1hdGlvblBhZ2UiOnsiYWN0aXZlIjoxLCJleHBvcnQiOjEsImNvb2tpZVNlYXJjaCI6IiIsInJlYWRDdXN0b21WYXJPckZ1bmMiOiIiLCJzdHJpbmdzIjoiXC9jb25maXJtYXRpb24iLCJ1cmxDb250YWlucyI6MSwiaHRtbENvbnRhaW5zIjowLCJzZWFyY2hETE9iamVjdCI6IiIsInNlYXJjaERMS2V5IjoiIiwic2VsZWN0b3IiOiIiLCJ1c2VMYXN0IjowLCJjb29raWVCYWNrdXAiOjAsInR5cGUiOiJ0ZXh0IiwiYXR0ciI6IiIsImN1c3RvbU92ZXJSaWRlIjoiIn0sIk9yZGVyTnVtYmVyIjp7ImFjdGl2ZSI6MSwiZXhwb3J0IjoxLCJjb29raWVTZWFyY2giOiIiLCJyZWFkQ3VzdG9tVmFyT3JGdW5jIjoiIiwic3RyaW5ncyI6IiIsInVybENvbnRhaW5zIjowLCJodG1sQ29udGFpbnMiOjAsInNlYXJjaERMT2JqZWN0IjoiIiwic2VhcmNoRExLZXkiOiIiLCJzZWxlY3RvciI6Ii5UeXBvZ3JhcGh5LW1vZHVsZV9fYm9keV9fX0sxb2J1LlR5cG9ncmFwaHktbW9kdWxlX19ib2xkX19fYms0YjQiLCJ1c2VMYXN0IjowLCJjb29raWVCYWNrdXAiOjAsInR5cGUiOiJ0ZXh0IiwiYXR0ciI6IiJ9LCJPcmRlclZhbHVlIjp7ImFjdGl2ZSI6MSwiZXhwb3J0IjoxLCJjb29raWVTZWFyY2giOiIiLCJyZWFkQ3VzdG9tVmFyT3JGdW5jIjoiIiwic3RyaW5ncyI6IiIsInVybENvbnRhaW5zIjowLCJodG1sQ29udGFpbnMiOjAsInNlYXJjaERMT2JqZWN0IjoiIiwic2VhcmNoRExLZXkiOiIiLCJzZWxlY3RvciI6IiNyb290ID4gZGl2ID4gbWFpbiA+IGRpdiA+IGRpdi5JbnZvaWNlLW1vZHVsZV9faW52b2ljZV9fX1M1bW56ID4gZGl2Lkludm9pY2UtbW9kdWxlX19pbnZvaWNlUm93X19fQ1BpamIgPiBwOm50aC1jaGlsZCgyKSIsInVzZUxhc3QiOjAsImNvb2tpZUJhY2t1cCI6MCwidHlwZSI6InRleHQiLCJhdHRyIjoiIiwiZnVuY3MiOlt7InR5cGUiOiJzcGVjaWFsIiwidmFscyI6WyIiLCIiXX1dfSwiRnJvbVJhaWxjYXJkVG9GYW1pbHkiOnsiYWN0aXZlIjoxLCJleHBvcnQiOjEsImNvb2tpZVNlYXJjaCI6IiIsInJlYWRDdXN0b21WYXJPckZ1bmMiOiJGcm9tUmFpbGNhcmRUb0ZhbWlseSIsInN0cmluZ3MiOiIiLCJ1cmxDb250YWlucyI6MCwiaHRtbENvbnRhaW5zIjowLCJzZWFyY2hETE9iamVjdCI6IiIsInNlYXJjaERMS2V5IjoiIiwic2VsZWN0b3IiOiIiLCJ1c2VMYXN0IjowLCJjb29raWVCYWNrdXAiOjAsInR5cGUiOiJ0ZXh0IiwiYXR0ciI6IiJ9fSwicmVmcyI6W10sImRiIjowLCJvdmVybGF5c191cmwiOiJodHRwczpcL1wvanMuc21jdC5pb1wvb1wvb3ZlcmxheXMtdjYuMDcuanMiLCJvdmVybGF5c19kYXRhX3VybCI6Imh0dHBzOlwvXC9zbWN0LmNvXC9vdjVcL2xvYWRcLyIsIm92ZXJsYXlzX2VuZ2FnZV91cmwiOiJodHRwczpcL1wvZXAuc21jdC5jb1wvb3Y0XC9lXC8iLCJpbnNpZ2h0c191cmwiOiJodHRwczpcL1wvZXAuc21jdC5jb1wvaW5zaWdodHNcLyIsImNsaWVudF9kZWJ1Z191cmwiOiJodHRwczpcL1wvanMuc21jdC5pb1wvZHBcL2NsaWVudERlYnVnLXYyLjAwLmpzIiwiY2xpZW50X2RlYnVnX2RhdGEiOiJodHRwczpcL1wvc21jdC5jb1wvY2xkYkRhdGFcLyIsImxzX2VuZHBvaW50IjoiaHR0cHM6XC9cL2xzLnNtY3QuaW9cL2xzZTEuMy5odG1sIiwidGFnX3ByZXZpZXciOiJkZWZhdWx0IiwicHh0X3ZlcnNpb24iOiIyYSIsInB4dF9pZGVudGl0eV9wb29sX2lkIjoiZXUtd2VzdC0xOjlhMjhjYmRlLTM4M2UtNGM1Yi1iZGRkLTNiMzdhOWE3ZDFiZSJ9LCJzcmNfY29faW8iOiJhdXRvIiwicnVsZXNMaXN0IjpbeyJydWxlbmFtZSI6IlJhaWxjYXJkLmNvLnVrIC0gTXVsdGkgQ1RBIiwidXJscyI6eyJibGFja2xpc3QiOlsiXC9jb25maXJtYXRpb24iXSwid2hpdGVsaXN0IjpbIlwiaHR0cHM6XC9cL3d3dy5yYWlsY2FyZC5jby51a1wvXCIiXX0sInJlZnMiOnsiYmxhY2tsaXN0IjpbXSwid2hpdGVsaXN0IjpbXX0sImxvY3MiOnsiYmxhY2tsaXN0IjpbXSwid2hpdGVsaXN0IjpbXX0sImR5bkJhc2tldE1pblF0eSI6IiIsInZpc2l0b3JzIjoiYWxsIiwibm90aWZpY2F0aW9uc0FjY2VwdGVkIjoiYW55IiwiZGVsYXkiOiIiLCJwYWdlVmlld3MiOiIiLCJmaWx0ZXIiOiIiLCJmaWx0ZXJHcm91cCI6IiIsInRpbWVTdGFydCI6IjIwMjItMDktMjAgMDA6MDA6MDEiLCJ0aW1lRW5kIjoiIiwib3ZlcmxheXMiOnsiZGVza3RvcCI6eyJpZCI6NTIzOTB9LCJtb2JpbGUiOnsiaWQiOjUyMzkzfSwidGFibGV0Ijp7ImlkIjo1MjM5Mn19fSx7InJ1bGVuYW1lIjoiMTYtMTcgUmFpbGNhcmQgLSBSb3VuZGVsIiwidXJscyI6eyJibGFja2xpc3QiOlsiXC9jb25maXJtYXRpb24iLCJzZWN1cmUuIiwiNTIzOTAiXSwid2hpdGVsaXN0IjpbImh0dHBzOlwvXC93d3cuMTYtMTdzYXZlci5jby51a1wvIl19LCJyZWZzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJsb2NzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJkeW5CYXNrZXRNaW5RdHkiOiIiLCJ2aXNpdG9ycyI6ImFsbCIsIm5vdGlmaWNhdGlvbnNBY2NlcHRlZCI6ImFueSIsImRlbGF5IjoiIiwicGFnZVZpZXdzIjoiIiwiZmlsdGVyIjoiIiwiZmlsdGVyR3JvdXAiOiIiLCJ0aW1lU3RhcnQiOiIiLCJ0aW1lRW5kIjoiIiwib3ZlcmxheXMiOnsiZGVza3RvcCI6eyJpZCI6MTQ1MDY0fSwibW9iaWxlIjp7ImlkIjoxNTQ2NDN9LCJ0YWJsZXQiOnsiaWQiOjE1NDY0Mn19fSx7InJ1bGVuYW1lIjoiMTYtMjUgUmFpbGNhcmQgLSBSb3VuZGVsIiwidXJscyI6eyJibGFja2xpc3QiOlsiXC9jb25maXJtYXRpb24iLCJzZWN1cmUuIiwiNTIzOTAiXSwid2hpdGVsaXN0IjpbImh0dHBzOlwvXC93d3cuMTYtMjVyYWlsY2FyZC5jby51a1wvIl19LCJyZWZzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJsb2NzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJkeW5CYXNrZXRNaW5RdHkiOiIiLCJ2aXNpdG9ycyI6ImFsbCIsIm5vdGlmaWNhdGlvbnNBY2NlcHRlZCI6ImFueSIsImRlbGF5IjoiIiwicGFnZVZpZXdzIjoiIiwiZmlsdGVyIjoiIiwiZmlsdGVyR3JvdXAiOiIiLCJ0aW1lU3RhcnQiOiIiLCJ0aW1lRW5kIjoiIiwib3ZlcmxheXMiOnsiZGVza3RvcCI6eyJpZCI6MTU4MjYyfSwibW9iaWxlIjp7ImlkIjoxNTgyNjR9LCJ0YWJsZXQiOnsiaWQiOjE1ODI2M319fSx7InJ1bGVuYW1lIjoiMjYtMzAgUmFpbGNhcmQgLSBSb3VuZGVsIiwidXJscyI6eyJibGFja2xpc3QiOlsiXC9jb25maXJtYXRpb24iLCJzZWN1cmUuIiwiNTIzOTAiXSwid2hpdGVsaXN0IjpbImh0dHBzOlwvXC93d3cuMjYtMzByYWlsY2FyZC5jby51a1wvIl19LCJyZWZzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJsb2NzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJkeW5CYXNrZXRNaW5RdHkiOiIiLCJ2aXNpdG9ycyI6ImFsbCIsIm5vdGlmaWNhdGlvbnNBY2NlcHRlZCI6ImFueSIsImRlbGF5IjoiIiwicGFnZVZpZXdzIjoiIiwiZmlsdGVyIjoiIiwiZmlsdGVyR3JvdXAiOiIiLCJ0aW1lU3RhcnQiOiIiLCJ0aW1lRW5kIjoiIiwib3ZlcmxheXMiOnsiZGVza3RvcCI6eyJpZCI6MTU4NTE1fSwibW9iaWxlIjp7ImlkIjoxNTg1MTd9LCJ0YWJsZXQiOnsiaWQiOjE1ODUxNn19fSx7InJ1bGVuYW1lIjoiU2VuaW9yIFJhaWxjYXJkIC0gUm91bmRlbCIsInVybHMiOnsiYmxhY2tsaXN0IjpbIlwvY29uZmlybWF0aW9uIiwic2VjdXJlLiIsIjUyMzkwIl0sIndoaXRlbGlzdCI6WyJodHRwczpcL1wvd3d3LnNlbmlvci1yYWlsY2FyZC5jby51a1wvIl19LCJyZWZzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJsb2NzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJkeW5CYXNrZXRNaW5RdHkiOiIiLCJ2aXNpdG9ycyI6ImFsbCIsIm5vdGlmaWNhdGlvbnNBY2NlcHRlZCI6ImFueSIsImRlbGF5IjoiIiwicGFnZVZpZXdzIjoiIiwiZmlsdGVyIjoiIiwiZmlsdGVyR3JvdXAiOiIiLCJ0aW1lU3RhcnQiOiIiLCJ0aW1lRW5kIjoiIiwib3ZlcmxheXMiOnsiZGVza3RvcCI6eyJpZCI6MTU4MjczfSwibW9iaWxlIjp7ImlkIjoxNTgyNzV9LCJ0YWJsZXQiOnsiaWQiOjE1ODI3NH19fSx7InJ1bGVuYW1lIjoiRmFtaWx5ICYgRnJpZW5kcyBSYWlsY2FyZCAtIFJvdW5kZWwiLCJ1cmxzIjp7ImJsYWNrbGlzdCI6WyJcL2NvbmZpcm1hdGlvbiIsInNlY3VyZS4iLCI1MjM5MCJdLCJ3aGl0ZWxpc3QiOlsiaHR0cHM6XC9cL3d3dy5mYW1pbHlhbmRmcmllbmRzLXJhaWxjYXJkLmNvLnVrXC8iXX0sInJlZnMiOnsiYmxhY2tsaXN0IjpbXSwid2hpdGVsaXN0IjpbXX0sImxvY3MiOnsiYmxhY2tsaXN0IjpbXSwid2hpdGVsaXN0IjpbXX0sImR5bkJhc2tldE1pblF0eSI6IiIsInZpc2l0b3JzIjoiYWxsIiwibm90aWZpY2F0aW9uc0FjY2VwdGVkIjoiYW55IiwiZGVsYXkiOiIiLCJwYWdlVmlld3MiOiIiLCJmaWx0ZXIiOiIiLCJmaWx0ZXJHcm91cCI6IiIsInRpbWVTdGFydCI6IiIsInRpbWVFbmQiOiIiLCJvdmVybGF5cyI6eyJkZXNrdG9wIjp7ImlkIjoxNTgyNzZ9LCJtb2JpbGUiOnsiaWQiOjE1ODI3OH0sInRhYmxldCI6eyJpZCI6MTU4Mjc3fX19LHsicnVsZW5hbWUiOiJUd28gVG9nZXRoZXIgUmFpbGNhcmQgLSBSb3VuZGVsIiwidXJscyI6eyJibGFja2xpc3QiOlsiXC9jb25maXJtYXRpb24iLCJzZWN1cmUuIiwiNTIzOTAiXSwid2hpdGVsaXN0IjpbImh0dHBzOlwvXC93d3cudHdvdG9nZXRoZXItcmFpbGNhcmQuY28udWtcLyJdfSwicmVmcyI6eyJibGFja2xpc3QiOltdLCJ3aGl0ZWxpc3QiOltdfSwibG9jcyI6eyJibGFja2xpc3QiOltdLCJ3aGl0ZWxpc3QiOltdfSwiZHluQmFza2V0TWluUXR5IjoiIiwidmlzaXRvcnMiOiJhbGwiLCJub3RpZmljYXRpb25zQWNjZXB0ZWQiOiJhbnkiLCJkZWxheSI6IiIsInBhZ2VWaWV3cyI6IiIsImZpbHRlciI6IiIsImZpbHRlckdyb3VwIjoiIiwidGltZVN0YXJ0IjoiIiwidGltZUVuZCI6IiIsIm92ZXJsYXlzIjp7ImRlc2t0b3AiOnsiaWQiOjE1ODUyNH0sIm1vYmlsZSI6eyJpZCI6MTU4NTI2fSwidGFibGV0Ijp7ImlkIjoxNTg1MjV9fX0seyJydWxlbmFtZSI6Ik5ldHdvcmsgUmFpbGNhcmQgLSBSb3VuZGVsIiwidXJscyI6eyJibGFja2xpc3QiOlsiXC9jb25maXJtYXRpb24iLCJzZWN1cmUuIiwiNTIzOTAiXSwid2hpdGVsaXN0IjpbImh0dHBzOlwvXC93d3cubmV0d29yay1yYWlsY2FyZC5jby51a1wvIl19LCJyZWZzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJsb2NzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJkeW5CYXNrZXRNaW5RdHkiOiIiLCJ2aXNpdG9ycyI6ImFsbCIsIm5vdGlmaWNhdGlvbnNBY2NlcHRlZCI6ImFueSIsImRlbGF5IjoiIiwicGFnZVZpZXdzIjoiIiwiZmlsdGVyIjoiIiwiZmlsdGVyR3JvdXAiOiIiLCJ0aW1lU3RhcnQiOiIiLCJ0aW1lRW5kIjoiIiwib3ZlcmxheXMiOnsiZGVza3RvcCI6eyJpZCI6MTU4NTI3fSwibW9iaWxlIjp7ImlkIjoxNTg1Mjl9LCJ0YWJsZXQiOnsiaWQiOjE1ODUyOH19fSx7InJ1bGVuYW1lIjoiVmV0ZXJhbnMgUmFpbGNhcmQgLSBSb3VuZGVsIiwidXJscyI6eyJibGFja2xpc3QiOlsiXC9jb25maXJtYXRpb24iLCJzZWN1cmUuIiwiNTIzOTAiXSwid2hpdGVsaXN0IjpbImh0dHBzOlwvXC93d3cudmV0ZXJhbnMtcmFpbGNhcmQuY28udWtcLyJdfSwicmVmcyI6eyJibGFja2xpc3QiOltdLCJ3aGl0ZWxpc3QiOltdfSwibG9jcyI6eyJibGFja2xpc3QiOltdLCJ3aGl0ZWxpc3QiOltdfSwiZHluQmFza2V0TWluUXR5IjoiIiwidmlzaXRvcnMiOiJhbGwiLCJub3RpZmljYXRpb25zQWNjZXB0ZWQiOiJhbnkiLCJkZWxheSI6IiIsInBhZ2VWaWV3cyI6IiIsImZpbHRlciI6IiIsImZpbHRlckdyb3VwIjoiIiwidGltZVN0YXJ0IjoiIiwidGltZUVuZCI6IiIsIm92ZXJsYXlzIjp7ImRlc2t0b3AiOnsiaWQiOjE1ODUzM30sIm1vYmlsZSI6eyJpZCI6MTU4NTM1fSwidGFibGV0Ijp7ImlkIjoxNTg1MzR9fX0seyJydWxlbmFtZSI6IkRpc2FibGVkIFJhaWxjYXJkIC0gUm91bmRlbCIsInVybHMiOnsiYmxhY2tsaXN0IjpbIlwvY29uZmlybWF0aW9uIiwic2VjdXJlLiIsIjUyMzkwIl0sIndoaXRlbGlzdCI6WyJodHRwczpcL1wvd3d3LmRpc2FibGVkcGVyc29ucy1yYWlsY2FyZC5jby51a1wvIl19LCJyZWZzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJsb2NzIjp7ImJsYWNrbGlzdCI6W10sIndoaXRlbGlzdCI6W119LCJkeW5CYXNrZXRNaW5RdHkiOiIiLCJ2aXNpdG9ycyI6ImFsbCIsIm5vdGlmaWNhdGlvbnNBY2NlcHRlZCI6ImFueSIsImRlbGF5IjoiIiwicGFnZVZpZXdzIjoiIiwiZmlsdGVyIjoiIiwiZmlsdGVyR3JvdXAiOiIiLCJ0aW1lU3RhcnQiOiIiLCJ0aW1lRW5kIjoiIiwib3ZlcmxheXMiOnsiZGVza3RvcCI6eyJpZCI6MTU4Mjg5fSwibW9iaWxlIjp7ImlkIjoxNTgyOTF9LCJ0YWJsZXQiOnsiaWQiOjE1ODI5MH19fV0sInBsdWdpbnMiOnsiYXV0b0luc2VydCI6eyJ1cmwiOiJcL2ZhbWlseS1hbmQtZnJpZW5kcyIsImlucHV0IjoiI3Byb21vLWNvZGUiLCJob2xkZXIiOiIiLCJob2xkZXJEaXNwbGF5IjoiYmxvY2siLCJlbG1BbmltYXRlIjoiIiwiZWxtQW5pbWF0ZUNsYXNzIjoicnViYmVyQmFuZCIsInNlY3NEaXNwIjo2MDAsInRpbWVvdXQiOjIwMDB9LCJ0cmFja2luZyI6eyJBQm9uIjowLCJ0eXBlIjoiMSIsImNvbmZpcm1QYWdlIjoiQ29uZmlybWF0aW9uUGFnZSIsIm9yZGVyVmFsdWUiOiJPcmRlclZhbHVlIiwib3JkZXJJRCI6Ik9yZGVyTnVtYmVyIiwiY3VycmVuY3kiOiJpZ25vcmUiLCJvcmRlckNvdW50IjoiaWdub3JlIiwicHgxIjoiaHR0cHM6XC9cL3Ricy50cmFkZWRvdWJsZXIuY29tXC9yZXBvcnQ/b3JnYW5pemF0aW9uPTIyNTY0NjYmZXZlbnQ9NDAxMDM3Jm9yZGVyTnVtYmVyPXtPcmRlck51bWJlcn0mb3JkZXJWYWx1ZT17T3JkZXJWYWx1ZX0mY3VycmVuY3k9R0JQJnR5cGU9aWZyYW1lIiwicHgxTG9hZCI6ImltZyIsImVoIjowfX0sInVzZUxvYyI6MCwiaXAiOiI1MS4xOTQuOC4yNDgiLCJpcGIiOmZhbHNlLCJkZXZpY2UiOmZhbHNlLCJ0IjowLjAwMTMwOCwibG9jU2lnIjoiZmVkNTY0MmY3NTY0MmU2Njc5OThhY2UxNDMxM2FiMDMifQ=='
	};
}

(function(w, d) {
	var src_co_io = 'auto';
	var tld = '';

	if(src_co_io === 'co' || src_co_io === 'io') {
		tld = src_co_io;
		sessionStorage.setItem('smc_cdn_source', tld);
	} else {
		tld  = sessionStorage.getItem('smc_cdn_source');
	}

	var cspCheck = function(cb) {
		if(tld !== null) {
			cb();
		} else {
			tld = 'io';
			var ioTest = new XMLHttpRequest();
			ioTest.open('HEAD', 'https://js.smct.' + tld + '/csp/csp.js', true);
			ioTest.send();
			ioTest.onerror = function() {
				tld = 'co'
				var coTest = new XMLHttpRequest();
				coTest.open('HEAD', 'https://js.smct.' + tld + '/csp/csp.js', true);
				coTest.send();
				coTest.onerror = function() {
					tld = 'co';
					cb();
				}
				coTest.onload = function() {
					tld = 'co';
					sessionStorage.setItem('smc_cdn_source', tld);
					cb();
				}
			}
			ioTest.onload = function() {
				tld = 'io';
				sessionStorage.setItem('smc_cdn_source', tld);
				cb();
			}
		}
	}

	var addJS = function(scriptUrl, callback) {
        var url = window.$smctResources.getURL(scriptUrl);
        var sriValue = window.$smctResources.getSRI(scriptUrl);
			if(url.indexOf('://l.smct') === -1 && url.indexOf('://dev.smct') === -1 && tld !== undefined) {
				url = url.replace(/smct.(c|i)o/i, 'smct.' + tld);
			}
		var h = d.getElementsByTagName("head")[0],
			j = d.createElement('script');
		j.type = 'text/javascript';
		j.src = url;
		j.charset = 'utf-8';
		h.appendChild(j);
		j.onload = function() {
			if(callback) {
				callback();
			}
		};
	}

	try{
		cspCheck(function cspChecker() {
			addJS('tag_url', function addingJS() {
				window.$smcCallCustomScripts = function() {
					$smcT5.CustomScripts = {};
					try {
						$smcT5.CustomScripts.TagCode = function(){
    // J.M - the overlays have a custom rdl parameter added to the tracking link, this code will pick up this parameter, and apply the code to the voucher code box
    (function AutoInsertFromURLParams() {
        const searchParams = new URLSearchParams(window.location.search);
        const code = searchParams.get('smc_code');
        if (code){ 
            let obj = {};
            obj.v = btoa(code);
            obj.d = Date.now();
            obj.u = null;
            obj.e = 2;
            let JsonItem = JSON.stringify(obj);
            $smcT5.CookieManager.create('smc_vc', JsonItem, 60*24*365);
            const promoEl = document.querySelector('#promo-code');
            promoEl.value = code;
            promoEl.classList.add('smct-animated');
            promoEl.classList.add('smct-rubberBand');
        }
    })();
} 

$smcT5.CustomScripts.FromRailcardToFamily = window.location.href.indexOf('https://www.familyandfriends-railcard.co.uk/') > -1 && document.referrer.indexOf('https://www.railcard.co.uk/') > -1 ? true : false;
					} catch(e) {
						console.error("CustomScripts Error: ", e);
					}
				}
			});
		});
	} catch(e) {
		console.log(e);
	}
}(window, document));

